<?php $__env->startSection('main-content'); ?>
<!-- DataTales Example -->
<div class="card shadow mb-4 ml-2 mr-2">
  <div class="row">
    <div class="col-md-12">
      <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
  <div class="card-header py-3">
    <h4 class="font-weight-bold float-left">Aset</h4>
    <a href="<?php echo e(route('aset.create')); ?>" class="btn btn-primary btn-sm float-right" data-toggle="tooltip" data-placement="bottom" title="Add User"><i class="fas fa-plus"></i> Tambah Aset</a>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <?php if(count($asets)>0): ?>
      <table class="table table-bordered" id="aset-dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>Nama Aset</th>
            <th>Kategori</th>
            <th>Sub Kategori</th>
            <th>Stok</th>
            <th>Foto</th>
            <th>Rentang Maintenance</th>
            <th>Rentang Pergantian</th>
            <th>Status</th>
            <th>Opsi</th>
          </tr>
        </thead>
        <tbody>

          <?php $__currentLoopData = $asets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
          $sub_cat_info=DB::table('categories')->select('title')->where('id',$aset->child_cat_id)->get();
          // dd($sub_cat_info);
          ?>
          <tr>
            <td><?php echo e($aset->title); ?></td>
            <td><?php echo e($aset->cat_info['title']); ?></td>
            <td><?php echo e($aset->sub_cat_info['title']); ?></td>
            <td>
              <?php if($aset->stock>0): ?>
              <span class="badge badge-primary"><?php echo e($aset->stock); ?></span>
              <?php else: ?>
              <span class="badge badge-danger"><?php echo e($aset->stock); ?></span>
              <?php endif; ?>
            </td>
            <td>
              <?php if($aset->photo): ?>
              <?php
              $photo=explode(',',$aset->photo);
              // dd($photo);
              ?>
              <img src="<?php echo e($photo[0]); ?>" class="img-fluid" style="max-width:80px" alt="<?php echo e($aset->photo); ?>">
              <?php else: ?>
              <img src="<?php echo e(asset('backend/img/thumbnail-default.jpg')); ?>" class="img-fluid" style="max-width:80px" alt="avatar.png">
              <?php endif; ?>
            </td>
            <td><?php echo e($aset->rentang); ?> Hari</td>
            <td><?php echo e($aset->ganti); ?> Bulan</td>
            <td>
              <?php if($aset->status=='active'): ?>
              <span class="badge badge-success"><?php echo e($aset->status); ?></span>
              <?php else: ?>
              <span class="badge badge-warning"><?php echo e($aset->status); ?></span>
              <?php endif; ?>
            </td>
            <td>
              <a href="<?php echo e(route('aset.edit',$aset->id)); ?>" class="btn btn-primary btn-sm float-left mr-1" style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip" title="edit" data-placement="bottom"><i class="fas fa-edit"></i></a>

              <form method="POST" action="<?php echo e(route('aset.destroy',[$aset->id])); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('delete'); ?>
                <button class="btn btn-danger btn-sm dltBtn" data-id="<?php echo e($aset->id); ?>" style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip" data-placement="bottom" title="Delete"><i class="fas fa-trash-alt"></i></button>
              </form>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <div class="d-flex justify-content-center">
        <?php echo e($asets->links('pagination::bootstrap-4')); ?> <!-- Pagination links with Bootstrap 4 style -->
      </div>
      <?php else: ?>
      <h6 class="text-center">Aset Kosong !!! Tolong Tambah Aset</h6>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" />

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>

<!-- Page level plugins -->
<script src="<?php echo e(asset('backend/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('backend/js/demo/datatables-demo.js')); ?>"></script>
<script>
  $('#aset-dataTable').DataTable({
    "scrollX": false,
    "columnDefs": [{
      "orderable": false,
      "targets": [7, 8]
    }],
    "paging": false,
    "info": false
  });


  // Sweet alert

  function deleteData(id) {

  }
</script>
<script>
  $(document).ready(function() {
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });
    $('.dltBtn').click(function(e) {
      var form = $(this).closest('form');
      var dataID = $(this).data('id');
      // alert(dataID);
      e.preventDefault();
      swal({
          title: "Apakah kamu yakin?",
          text: "Dengan menghapus aset ini, kamu tidak bisa mengembalikannya!",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
            form.submit();
          } else {
            swal("Data Aset Aman!");
          }
        });
    })
  })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aset-it\resources\views/backend/aset/index.blade.php ENDPATH**/ ?>