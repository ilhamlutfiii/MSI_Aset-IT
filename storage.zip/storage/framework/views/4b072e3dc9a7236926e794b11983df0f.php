<!DOCTYPE html>
<html lang="en">

<head>
  <title>MSI || Login</title>
  <?php echo $__env->make('backend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body style="background-image: url('../storage/photos/1/bg.jpg'); background-repeat: no-repeat; background-size: cover;">

  <div class="container">

    <!-- Outer Row -->
    <div class="row justify-content-center">

      <div class="col-xl-10 col-lg-12 col-md-9 mt-5">

        <div class="o-hidden border-0 shadow-lg my-5">
          <div class="p-0">
            <!-- Nested Row within Card Body -->
            <div class="row">

              <?php
              $settings = DB::table('settings')->first();
              ?>

              
              <div class="col-lg-6 d-none d-lg-block bg-light" style="background: url('<?php echo e($settings->logo); ?>'); background-position: center; background-size: 400px 120px; background-repeat: no-repeat;"></div>
              <div class="col-lg-6">
                <div class="pt-4 pb-4 pl-5 pr-5 " style="background-color:rgba(0, 0, 0, 0.5);">
                  <div class="text-center">
                    <h2 class="text-white">Selamat Datang!</h2>
                    <img src="../storage/photos/1/user.png" style="max-width: 100px;">
                  </div>
                  <form class="user" method="POST" action="<?php echo e(route('login.submit')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                      <input type="user_nid" class="form-control form-control-user <?php $__errorArgs = ['user_nid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="user_nid" value="<?php echo e(old('user_nid')); ?>" placeholder="User NID" autofocus>
                      <?php $__errorArgs = ['user_nid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                      </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group">
                      <input type="password" class="form-control form-control-user <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="exampleInputPassword" placeholder="Password" name="password" required autocomplete="current-password">
                      <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                      <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                      </span>
                      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                    <button type="submit" class="btn btn-primary btn-user btn-block">
                      Login
                    </button>
                  </form>
                  <hr>
                </div>
              </div>
            </div>
          </div>
        </div>

      </div>

    </div>

  </div>
</body>

</html><?php /**PATH C:\xampp\htdocs\aset-it\resources\views/frontend/pages/login.blade.php ENDPATH**/ ?>