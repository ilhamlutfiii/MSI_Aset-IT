<?php $__env->startSection('title', 'MSI || DASHBOARD'); ?>
<?php $__env->startSection('main-content'); ?>
<div class="container-fluid">
  <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <!-- Page Heading -->
  <div class="d-sm-flex align-items-center justify-content-between mb-4">
    <h2 class="font-weight-bold float-left">Dashboard</h2>
  </div>

  <!-- Content Row -->
  <div class="row">
    <!-- User -->
    <div class="col-xl-3 col-md-6 mb-4">
      <a href="<?php echo e(route('users.index')); ?>" style="text-decoration: none;">
        <div class="card border-left-primary shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">User</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(\App\User::countActiveUser()); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-user fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </a>
    </div>

    <!-- Asets -->
    <div class="col-xl-3 col-md-6 mb-4">
      <a href="<?php echo e(route('aset.index')); ?>" style="text-decoration: none;">
        <div class="card border-left-success shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Asets</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(\App\Models\Aset::countActiveAset()); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-cubes fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </a>
    </div>

    <!-- Pinjam -->
    <div class="col-xl-3 col-md-6 mb-4">
      <a href="<?php echo e(route('pinjam.index')); ?>" style="text-decoration: none;">
        <div class="card border-left-warning shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">Pinjam</div>
                <div class="row no-gutters align-items-center">
                  <div class="col-auto">
                    <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800"><?php echo e(\App\Models\Pinjam::countActivePinjam()); ?></div>
                  </div>
                </div>
              </div>
              <div class="col-auto">
                <i class="fas fa-clipboard-list fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
      </a>
    </div>


    <!-- Review -->
    <div class="col-xl-3 col-md-6 mb-4">
      <a href="<?php echo e(route('review.index')); ?>" style="text-decoration: none;">
        <div class="card border-left-danger shadow h-100 py-2">
          <div class="card-body">
            <div class="row no-gutters align-items-center">
              <div class="col mr-2">
                <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Review</div>
                <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e(\App\Models\AsetReview::countActiveReview()); ?></div>
              </div>
              <div class="col-auto">
                <i class="fas fa-comments fa-2x text-gray-300"></i>
              </div>
            </div>
          </div>
        </div>
    </div>
    </a>
  </div>
  <!-- Content Row -->
  <?php
  $showMaintenanceTable = false;
  foreach($maintenances as $maintenance) {
  $updated_at = \Carbon\Carbon::parse($maintenance->updated_at);
  $now = \Carbon\Carbon::now();
  $daysDiff = $now->diffInDays($updated_at);
  if($daysDiff >= $maintenance->rentang || $maintenance->mainStatus == 'Repair') {
  $showMaintenanceTable = true;
  break;
  }
  }
  ?>

  <?php if($showMaintenanceTable): ?>
  <div class="row">
    <div class="col-md-12">
      <div class="card">
        <div class="card-header py-3">
          <a href="<?php echo e(route('maintenance.index')); ?>" style="text-decoration: none;">
            <h4 class="font-weight-bold float-left">Maintenance</h4>
          </a>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-bordered" id="main-dataTable" width="100%" cellspacing="0">
              <thead>
                <tr>
                  <th>Nama Aset</th>
                  <th>Foto</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $maintenances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maintenance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $updated_at = \Carbon\Carbon::parse($maintenance->updated_at);
                $now = \Carbon\Carbon::now();
                $daysDiff = $now->diffInDays($updated_at);
                $daysLate = $daysDiff - $maintenance->rentang;
                $daysDiffs = $updated_at->diffInDays($now);
                $daysLeft = $maintenance->rentang - $daysDiffs;
                ?>

                <?php if($daysDiff >= $maintenance->rentang || $maintenance->mainStatus == 'Repair'): ?>
                <tr>
                  <td><?php echo e($maintenance->asets->title); ?></td>
                  <td>
                    <?php if($maintenance->asets->photo): ?>
                    <?php
                    $photo = explode(',', $maintenance->asets->photo);
                    ?>
                    <img src="<?php echo e($photo[0]); ?>" class="img-fluid" style="max-width:80px" alt="<?php echo e($maintenance->asets->photo); ?>">
                    <?php else: ?>
                    <img src="<?php echo e(asset('backend/img/thumbnail-default.jpg')); ?>" class="img-fluid" style="max-width:80px" alt="avatar.png">
                    <?php endif; ?>
                  </td>
                  <td>
                    <?php if($maintenance->mainStatus == 'Repair'): ?>
                    <p class="aset blink">Request Repair - <?php echo e($maintenance->ket_main); ?></p>
                    <?php endif; ?>
                    <?php if($daysDiff > $maintenance->rentang): ?>
                    <p class="aset blink">Sudah Telat Maintenance Selama <?php echo e($daysLate); ?> Hari</p>
                    <?php elseif($daysDiff == $maintenance->rentang && $maintenance->mainStatus != 'Repair'): ?>
                    <p class="aset blink">Hari ini waktunya maintenance</p>
                    <?php endif; ?>
                  </td>
                  <td>
                    <a href="<?php echo e(route('maintenance.show', $maintenance->asets->id)); ?>" class="btn btn-danger btn-sm float-left mr-1" data-toggle="tooltip" title="show" data-placement="bottom">Maintenance</a>
                  </td>
                </tr>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
            <div class="d-flex justify-content-center">
              <?php echo e($maintenances->links('pagination::bootstrap-4')); ?> <!-- Pagination links with Bootstrap 4 style -->
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<!-- Page level plugins -->
<script src="<?php echo e(asset('backend/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('backend/js/demo/datatables-demo.js')); ?>"></script>
<script>
  $(document).ready(function() {
    $('#main-dataTable').DataTable({
      "scrollX": false,
      "columnDefs": [{
        "orderable": false,
        "targets": [2, 3]
      }],
      "paging": false,
      "info": false
    });
  });

  // Sweet alert
  function deleteData(id) {
    // Function implementation
  }
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<style>
  .aset-info,
  .aset-info h4,
  .keterangan {
    color: red;
  }

  .aset {
    color: green;
  }

  @keyframes blink {
    0% {
      opacity: 1;
    }

    50% {
      opacity: 0;
    }

    100% {
      opacity: 1;
    }
  }

  .blink {
    animation: blink 1s infinite;
    color: red;
  }
</style>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aset-it\resources\views/backend/index.blade.php ENDPATH**/ ?>