<?php $__env->startSection('main-content'); ?>
<!-- DataTales Example -->
<div class="card shadow mb-4 ml-2 mr-2">
  <div class="row">
    <div class="col-md-12">
      <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
  </div>
  <div class="card-header py-3">
    <h4 class="font-weight-bold float-left">Maintenance</h4>
  </div>
  <div class="card-body">
    <div class="table-responsive">
      <?php if($maintenances->count() > 0): ?>
      <table class="table table-bordered" id="maintenance-dataTable" width="100%" cellspacing="0">
        <thead>
          <tr>
            <th>Aset</th>
            <th>Kategori</th>
            <th>Sub Kategori</th>
            <th>Foto</th>
            <th>Opsi</th>
          </tr>
        </thead>
        <tbody>

          <?php $__currentLoopData = $maintenances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $maintenance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
          $sub_cat_info = DB::table('categories')->select('title')->where('id', $maintenance->asets->child_cat_id)->get();
          ?>
          <tr>
            <td><?php echo e($maintenance->asets->title); ?></td>
            <td><?php echo e($maintenance->asets->cat_info['title']); ?></td>
            <td><?php echo e($maintenance->asets->sub_cat_info['title']); ?></td>
            <td>
              <?php if($maintenance->asets->photo): ?>
              <?php
              $photo = explode(',', $maintenance->asets->photo);
              ?>
              <img src="<?php echo e($photo[0]); ?>" class="img-fluid" style="max-width:80px" alt="<?php echo e($maintenance->asets->photo); ?>">
              <?php else: ?>
              <img src="<?php echo e(asset('backend/img/thumbnail-default.jpg')); ?>" class="img-fluid" style="max-width:80px" alt="avatar.png">
              <?php endif; ?>
            </td>
            <td>
              <a href="<?php echo e(route('maintenance.show', $maintenance->asets->id)); ?>" class="btn btn-warning btn-sm float-left mr-1" data-toggle="tooltip" title="show" data-placement="bottom"><i class="fas fa-eye"></i> Status</a>
              <a href="<?php echo e(route('maintenance.indexLog', $maintenance->id)); ?>" class="btn btn-primary btn-sm float-left mr-1" data-toggle="tooltip" title="history" data-placement="bottom">Log History</a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <div class="d-flex justify-content-center">
        <?php echo e($maintenances->links('pagination::bootstrap-4')); ?>

      </div>
      <?php else: ?>
      <h6 class="text-center">Maintenance Kosong!!! Tolong Tambah Aset Dahulu</h6>
      <?php endif; ?>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>

<!-- Page level plugins -->
<script src="<?php echo e(asset('backend/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('backend/js/demo/datatables-demo.js')); ?>"></script>
<script>
  $('#maintenance-dataTable').DataTable({
    "scrollX": false,
    "columnDefs": [{
      "orderable": false,
      "targets": [3, 4]
    }],
    "paging": false,
    "info": false
  });

  // Sweet alert

  function deleteData(id) {}
</script>
<script>
  $(document).ready(function() {
    $.ajaxSetup({
      headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
      }
    });
    $('.dltBtn').click(function(e) {
      var form = $(this).closest('form');
      var dataID = $(this).data('id');
      e.preventDefault();
      swal({
          title: "Are you sure?",
          text: "Once deleted, you will not be able to recover this data!",
          icon: "warning",
          buttons: true,
          dangerMode: true,
        })
        .then((willDelete) => {
          if (willDelete) {
            form.submit();
          } else {
            swal("Your data is safe!");
          }
        });
    })
  })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aset-it\resources\views/backend/maintenance/index.blade.php ENDPATH**/ ?>