

<?php $__env->startSection('main-content'); ?>
<!-- DataTales Example -->
<div class="card shadow mb-4 mr-2 ml-2">
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('user.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="card-header py-3">
        <h4 class="font-weight-bold float-left">Repair</h4>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <?php if(count($pinjams)>0): ?>

            <?php
            $siapDiambilExists = $pinjams->firstWhere('status', 'Telah Diambil') !== null;
            ?>

            <?php if($siapDiambilExists): ?>
            <table class="table table-bordered" id="order-dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Pinjam No.</th>
                        <th>Nama</th>
                        <th>Aset</th>
                        <th>QTY</th>
                        <th>Waktu Pinjam</th>
                        <th>Status</th>
                        <th>Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $pinjams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pinjam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($pinjam->status == 'Telah Diambil'): ?>
                    <tr>
                        <td><?php echo e($pinjam->pinjam_number); ?></td>
                        <td><?php echo e($pinjam->users->user_nama); ?></td>
                        <td><?php echo e($pinjam->asets->title); ?></td>
                        <td><?php echo e($pinjam->quantity); ?></td>
                        <td><?php echo e($pinjam->created_at->setTimezone('Asia/Jakarta')->format('d-m-Y')); ?>, <?php echo e($pinjam->created_at->setTimezone('Asia/Jakarta')->format('H:i')); ?> </td>
                        <td>
                            <?php if($pinjam->status=='Telah Diambil'): ?>
                            <span class="badge badge-success">Ready</span>
                            <?php else: ?>
                            <span class="badge badge-danger"><?php echo e($pinjam->status); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            $maintenance = DB::table('maintenances')->where('aset_id', $pinjam->aset_id)->first();
                            $status = $maintenance ? $maintenance->mainStatus : null;
                            ?>

                            <?php if($status == 'Repair' || $status == 'Sedang Diproses' || $status == 'Maintenance'): ?>
                            <a href="<?php echo e(route('user.bantuan.show', $pinjam->id)); ?>" class="btn btn-secondary btn-sm float-left mr-1" data-toggle="tooltip" title="View" data-placement="bottom"><i class="fas fa-eye"></i> Cek</a>
                            <?php else: ?>
                            <a href="<?php echo e(route('user.bantuan.show', $pinjam->id)); ?>" class="btn btn-danger btn-sm float-left mr-1" data-toggle="tooltip" title="View" data-placement="bottom"><i class="fas fa-tools"></i> Repair</a>
                            <?php endif; ?>
                        </td>

                    </tr>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="d-flex justify-content-center">
                <?php echo e($pinjams->links('pagination::bootstrap-4')); ?> <!-- Pagination links with Bootstrap 4 style -->
            </div>
            <?php else: ?>
            <h6 class="text-center">Tidak ada peminjaman yang ready!!!</h6>
            <?php endif; ?>
            <?php else: ?>
            <h6 class="text-center">Peminjaman Kosong!!!</h6>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>

<!-- Page level plugins -->
<script src="<?php echo e(asset('backend/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('backend/js/demo/datatables-demo.js')); ?>"></script>
<script>
    $('#order-dataTable').DataTable({
        "columnDefs": [{
            "orderable": false,
            "targets": [5, 6]
        }],
        "paging": false,
        "info": false
    });
</script>
<script>
    $(document).ready(function() {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('.dltBtn').click(function(e) {
            var form = $(this).closest('form');
            var dataID = $(this).data('id');
            // alert(dataID);
            e.preventDefault();
            swal({
                    title: "Apakah kamu yakin?",
                    text: "Dengan membatalkan peminjamanan aset ini?",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit();
                    } else {
                        swal("Peminjamanmu Aman!");
                    }
                });
        })
    })
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('user.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aset-it\resources\views/user/bantuan/index.blade.php ENDPATH**/ ?>