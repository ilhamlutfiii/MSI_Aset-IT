<?php $__env->startSection('meta'); ?>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name='copyright' content=''>
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title','MSI || Aset DETAIL'); ?>
<?php $__env->startSection('main-content'); ?>

<!-- Breadcrumbs -->
<div class="breadcrumbs">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="bread-inner">
					<ul class="bread-list">
						<li><a href="<?php echo e(route('home')); ?>">Home<i class="ti-arrow-right"></i></a></li>
						<li class="active"><a href="">Aset Details</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End Breadcrumbs -->

<!-- Shop Single -->
<section class="asetit single section">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="row">
					<div class="col-lg-6 col-12">
						<!-- aset Slider -->
						<div class="aset-gallery">
							<!-- Images slider -->
							<div class="flexslider-thumbnails">
								<ul class="slides">
									<?php
									$photo=explode(',',$aset_detail->photo);
									// dd($photo);
									?>
									<?php $__currentLoopData = $photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li data-thumb="<?php echo e($data); ?>" rel="adjustX:10, adjustY:">
										<img src="<?php echo e($data); ?>" alt="<?php echo e($data); ?>">
									</li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
							<!-- End Images slider -->
						</div>
						<!-- End aset slider -->
					</div>
					<div class="col-lg-6 col-12">
						<div class="aset-des">
							<!-- Description -->
							<div class="short">
								<h4><?php echo e($aset_detail->title); ?></h4>
								<div class="rating-main">
									<ul class="rating">
										<?php
										$rate=ceil($aset_detail->getReview->avg('rate'))
										?>
										<?php for($i=1; $i<=5; $i++): ?> <?php if($rate>=$i): ?>
											<li><i class="fa fa-star"></i></li>
											<?php else: ?>
											<li><i class="fa fa-star-o"></i></li>
											<?php endif; ?>
											<?php endfor; ?>
									</ul>
									<a href="#" class="total-review">(<?php echo e($aset_detail['getReview']->count()); ?>) Review</a>
								</div>

								<p class="description"><?php echo ($aset_detail->summary); ?></p>
							</div>
							<!--/ End Description -->

							<!-- aset -->
							<div class="aset-buy">
								<form action="<?php echo e(route('single-add-to-cart')); ?>" method="POST">
									<?php echo csrf_field(); ?>
									<div class="add-to-cart mt-4">
										<button type="submit" class="btn">Tambahkan Ke Keranjang</button>
										<!-- <a href="<?php echo e(route('add-to-wishlist',$aset_detail->slug)); ?>" class="btn min"><i class="ti-heart"></i></a> -->
									</div>
								</form>

								<p class="cat">Kategori :<a href="<?php echo e(route('aset-cat',$aset_detail->cat_info['slug'])); ?>"><?php echo e($aset_detail->cat_info['title']); ?></a></p>
								<?php if($aset_detail->sub_cat_info): ?>
								<p class="cat mt-1">Sub-Kategori :<a href="<?php echo e(route('aset-sub-cat',[$aset_detail->cat_info['slug'],$aset_detail->sub_cat_info['slug']])); ?>"><?php echo e($aset_detail->sub_cat_info['title']); ?></a></p>
								<?php endif; ?>
								<p class="availability">Stok : <?php if($aset_detail->stock>0): ?><span class="badge badge-success"><?php echo e($aset_detail->stock); ?></span><?php else: ?> <span class="badge badge-danger"><?php echo e($aset_detail->stock); ?></span> <?php endif; ?></p>
							</div>
							<!--/ End aset Buy -->
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-12">
						<div class="aset-info">
							<div class="nav-main">
								<!-- Tab Nav -->
								<ul class="nav nav-tabs" id="myTab" role="tablist">
									<li class="nav-item"><a class="nav-link active" data-toggle="tab" href="#description" role="tab">Deskripsi</a></li>
									<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#reviews" role="tab">Review</a></li>
									<li class="nav-item"><a class="nav-link" data-toggle="tab" href="#logs" role="tab">History Maintenance</a></li>
								</ul>
								<!--/ End Tab Nav -->
							</div>
							<div class="tab-content" id="myTabContent">
								<!-- Description Tab -->
								<div class="tab-pane fade show active" id="description" role="tabpanel">
									<div class="tab-single">
										<div class="row">
											<div class="col-12">
												<div class="single-des">
													<p><?php echo ($aset_detail->description); ?></p>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!--/ End Description Tab -->
								<!-- Reviews Tab -->
								<div class="tab-pane fade" id="reviews" role="tabpanel">
									<div class="tab-single review-panel">
										<div class="row">
											<div class="col-12">

												<!-- Review -->

												<div class="ratting-main">
													<div class="avg-ratting">
														<h4><?php echo e(ceil($aset_detail->getReview->avg('rate'))); ?> <span>(Rata-Rata Bintang)</span></h4>
														<span>Berdasarkan <?php echo e($aset_detail->getReview->count()); ?> Komentar</span>
													</div>
													<?php $__currentLoopData = $aset_detail['getReview']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<!-- Single Rating -->
													<div class="single-rating">
														<div class="rating-author">
															<?php if($data->user_info['photo']): ?>
															<img src="<?php echo e($data->user_info['photo']); ?>" alt="<?php echo e($data->user_info['photo']); ?>">
															<?php else: ?>
															<img src="<?php echo e(asset('backend/img/avatar.png')); ?>" alt="Profile.jpg">
															<?php endif; ?>
														</div>
														<div class="rating-des">
															<h6><?php echo e($data->user_info['user_nama']); ?></h6>
															<div class="ratings">

																<ul class="rating">
																	<?php for($i=1; $i<=5; $i++): ?> <?php if($data->rate>=$i): ?>
																		<li><i class="fa fa-star"></i></li>
																		<?php else: ?>
																		<li><i class="fa fa-star-o"></i></li>
																		<?php endif; ?>
																		<?php endfor; ?>
																</ul>
																<div class="rate-count">(<span><?php echo e($data->rate); ?></span> Bintang)</div>
															</div>
															<p><?php echo e($data->review); ?></p>
														</div>
													</div>
													<!--/ End Single Rating -->
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</div>

												<!--/ End Review -->

											</div>
										</div>
									</div>
								</div>
								<!--/ End Reviews Tab -->

								<!-- Logs Tab -->
								<div class="tab-pane fade" id="logs" role="tabpanel">
									<div class="tab-single log-panel">
										<div class="row">
											<div class="col-12">

												<!-- Logs -->
												<div class="comment-review">
													<div class="ratting-main">
														<div class="avg-ratting">
															<span>
																<h4> <?php echo e($aset_detail->getMainLog->count()); ?> History Maintenance</h4>
															</span>
														</div>
														<?php $__currentLoopData = $aset_detail['getMainLog']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<!-- History -->
														<div class="single-rating">
															<div class="log-author">
																<?php if($data->mainPhoto): ?>
																<img src="<?php echo e(asset('mainPhoto/' . $data->mainPhoto)); ?>" class="img-fluid zoom" alt="<?php echo e($data->mainPhoto); ?>">
																<?php else: ?>
																<img src="<?php echo e(asset('backend/img/avatar.png')); ?>" alt="Profile.jpg">
																<?php endif; ?>
															</div>
															<div class="log-des">
																<h6><?php echo e($data->ket_main); ?></h6>
																<br>
																<p><?php echo e($data->created_at); ?></p>
															</div>
														</div>
														<!--/ End History -->
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													</div>

													<!--/ End Logs -->

												</div>
											</div>
										</div>
									</div>
									<!--/ End Logs Tab -->
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
</section>
<!--/ End Shop Single -->

<!-- Start Related -->
<div class="aset-area most-popular related-aset section">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="section-title">
					<h2>Aset yang serupa</h2>
				</div>
			</div>
		</div>
		<div class="row">
			

			<div class="col-12">
				<div class="owl-carousel popular-slider">
					<?php $__currentLoopData = $aset_detail->rel_prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($data->id !==$aset_detail->id): ?>
					<?php
					$mainStatus = DB::table('maintenances')->where('aset_id', $data->id)->value('mainStatus');
					?>
					<?php if(!$mainStatus || $mainStatus != 'Diperbaiki' && $mainStatus != 'Sedang Diproses' && $mainStatus != 'Maintenance' && $mainStatus != 'Repair'): ?>

					<!-- Start Single aset -->
					<div class="single-aset">
						<div class="aset-img">
							<a href="<?php echo e(route('aset-detail',$data->slug)); ?>">
								<?php
								$photo=explode(',',$data->photo);
								?>
								<img class="default-img" src="<?php echo e($photo[0]); ?>" alt="<?php echo e($photo[0]); ?>">
								<img class="hover-img" src="<?php echo e($photo[0]); ?>" alt="<?php echo e($photo[0]); ?>">

							</a>
							<div class="button-head">
								<div class="aset-action">
									<a data-toggle="modal" data-target="#modelExample" title="Quick View" href="#"><i class=" ti-eye"></i><span>Quick Pinjam</span></a>
									<!-- <a title="Wishlist" href="#"><i class=" ti-heart "></i><span>Tambahkan Ke Wishlist</span></a> -->
								</div>
								<div class="aset-action-2">
									<a title="Tambahkan Ke Keranjang" href="#">Tambahkan Ke Keranjang</a>
								</div>
							</div>
						</div>
						<div class="aset-content">
							<h3><a href="<?php echo e(route('aset-detail',$data->slug)); ?>"><?php echo e($data->title); ?></a></h3>
						</div>
					</div>
					<!-- End Single aset -->
					<?php endif; ?>
					<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</div>
			
		</div>
	</div>
</div>
<!-- End Most Popular Area -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>



<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aset-it\resources\views/frontend/pages/aset_detail.blade.php ENDPATH**/ ?>