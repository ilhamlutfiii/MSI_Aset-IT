<?php $__env->startSection('title','MSI || HOME PAGE'); ?>
<?php $__env->startSection('main-content'); ?>

<!-- Start aset Area -->
<div class="aset-area section" style="background-color: #F6F7FB;">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title">
                    <h2>MSI Aset IT</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="aset-info">
                    <div class="nav-main">
                        <!-- Tab Nav -->
                        <ul class="nav nav-tabs filter-tope-group" id="myTab" role="tablist">
                            <?php
                            $categories=DB::table('categories')->where('status','active')->where('is_parent',1)->get();
                            ?>
                            <?php if($categories): ?>
                            <button class="btn" data-filter="*" style="border-radius:20%;">
                                Semua Aset IT
                            </button>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <button class="btn" data-filter=".<?php echo e($cat->id); ?>" style="border-radius:20%;">
                                <?php echo e($cat->title); ?>

                            </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>
                        <!--/ End Tab Nav -->
                    </div>


                    <div class="tab-content isotope-grid mt-5 mb-5" id="myTabContent">
                        <!-- Start Single Tab -->
                        <?php if($aset_lists): ?>
                        <?php $__currentLoopData = $aset_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$aset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                        $mainStatus = DB::table('maintenances')->where('aset_id', $aset->id)->value('mainStatus');
                        ?>
                        <?php if(!$mainStatus || $mainStatus != 'Diperbaiki' && $mainStatus != 'Sedang Diproses' && $mainStatus != 'Maintenance' && $mainStatus != 'Repair'): ?>
                        <div class="col-sm-6 col-md-4 col-lg-3 p-b-35 mt-2 isotope-item <?php echo e($aset->cat_id); ?>" >
                            <div class="single-aset">
                                <div class="aset-img">
                                    <a href="<?php echo e(route('aset-detail',$aset->slug)); ?>" class="mt-2 mb-5">
                                        <?php
                                        $photo=explode(',',$aset->photo);
                                        // dd($photo);
                                        ?>
                                        <img class="default-img" src="<?php echo e($photo[0]); ?>" alt="<?php echo e($photo[0]); ?>">
                                        

                                    </a>
                                    <div class="button-head">
                                        <div class="aset-action-2">
                                            <a title="Tambah ke keranjang" href="<?php echo e(route('add-to-cart',$aset->slug)); ?>"><i class="ti-shopping-cart"></i> Tambah ke keranjang</a>
                                        </div>
                                    </div>
                                </div>
                                <div class="aset-content ml-2 mb-3">
                                    <h3><a href="<?php echo e(route('aset-detail',$aset->slug)); ?>" style="color: black;"><?php echo e($aset->title); ?></a></h3>
                                    <h6><a href="<?php echo e(route('aset-detail',$aset->stock)); ?>">Stok: <?php echo e($aset->stock); ?></a></h6>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <!--/ End Single Tab -->
                        <?php endif; ?>

                        <!--/ End Single Tab -->

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- End aset Area -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .btn.active {
        background-color: #007bff;
        /* Warna biru */
        color: white;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    $(document).ready(function() {
        $(".btn").click(function() {
            $(".btn").removeClass("active");
            $(this).addClass("active");
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>
<script>
    /*==================================================================
        [ Isotope ]*/
    var $topeContainer = $('.isotope-grid');
    var $filter = $('.filter-tope-group');

    // filter items on button click
    $filter.each(function() {
        $filter.on('click', 'button', function() {
            var filterValue = $(this).attr('data-filter');
            $topeContainer.isotope({
                filter: filterValue
            });
        });

    });

    // init Isotope
    $(window).on('load', function() {
        var $grid = $topeContainer.each(function() {
            $(this).isotope({
                itemSelector: '.isotope-item',
                layoutMode: 'fitRows',
                percentPosition: true,
                animationEngine: 'best-available',
                masonry: {
                    columnWidth: '.isotope-item'
                }
            });
        });
    });

    var isotopeButton = $('.filter-tope-group button');

    $(isotopeButton).each(function() {
        $(this).on('click', function() {
            for (var i = 0; i < isotopeButton.length; i++) {
                $(isotopeButton[i]).removeClass('how-active1');
            }

            $(this).addClass('how-active1');
        });
    });
</script>
<script>
    function cancelFullScreen(el) {
        var requestMethod = el.cancelFullScreen || el.webkitCancelFullScreen || el.mozCancelFullScreen || el.exitFullscreen;
        if (requestMethod) { // cancel full screen.
            requestMethod.call(el);
        } else if (typeof window.ActiveXObject !== "undefined") { // Older IE.
            var wscript = new ActiveXObject("WScript.Shell");
            if (wscript !== null) {
                wscript.SendKeys("{F11}");
            }
        }
    }

    function requestFullScreen(el) {
        // Supports most browsers and their versions.
        var requestMethod = el.requestFullScreen || el.webkitRequestFullScreen || el.mozRequestFullScreen || el.msRequestFullscreen;

        if (requestMethod) { // Native full screen.
            requestMethod.call(el);
        } else if (typeof window.ActiveXObject !== "undefined") { // Older IE.
            var wscript = new ActiveXObject("WScript.Shell");
            if (wscript !== null) {
                wscript.SendKeys("{F11}");
            }
        }
        return false
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aset-it\resources\views/frontend/index.blade.php ENDPATH**/ ?>