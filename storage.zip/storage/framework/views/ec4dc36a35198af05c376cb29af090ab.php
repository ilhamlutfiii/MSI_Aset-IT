<?php $__env->startSection('title','MSI || ASET IT'); ?>

<?php $__env->startSection('main-content'); ?>

<!-- Breadcrumbs -->
<div class="breadcrumbs">
	<div class="container">
		<div class="row">
			<div class="col-12">
				<div class="bread-inner">
					<ul class="bread-list">
						<li><a href="<?php echo e(route('home')); ?>">Home<i class="ti-arrow-right"></i></a></li>
						<li class="active"><a href="javascript:void(0);">Aset IT</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- End Breadcrumbs -->
<form action="<?php echo e(route('asetit.filter')); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<!-- aset Style 1 -->
	<section class="aset-area asetit-sidebar asetit-list asetit section" style="background-color: #F6F7FB;">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-4 col-12">
					<div class="asetit-sidebar">
						<!-- Single Widget -->
						<ul class="navbar-nav bg-gradient-light sidebar sidebar-light accordion" id="accordionSidebar">
							<div class="single-widget category">
								<h3 class="title">Kategori</h3>
								<ul class="category-list">
									<?php
									$menu = App\Models\Category::getAllParentWithChild();
									?>
									<?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li class="nav-item">
										<a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#categorysCollapse<?php echo e($cat_info->id); ?>" aria-expanded="true" aria-controls="categorysCollapse<?php echo e($cat_info->id); ?>">
											<span><?php echo e($cat_info->title); ?></span>
											<span class="arrow-icon"><i class="fas fa-chevron-right"></i></span>
										</a>
										<div id="categorysCollapse<?php echo e($cat_info->id); ?>" class="collapse" aria-labelledby="heading<?php echo e($cat_info->id); ?>" data-parent="#accordionSidebar">
											<div class="bg-white py-2 collapse-inner rounded">
												<?php if($cat_info->child_cat->count() > 0): ?>
												<ul>
													<?php $__currentLoopData = $cat_info->child_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<li><a class="collapse-item" href="<?php echo e(route('aset-sub-cat',[$cat_info->slug,$sub_menu->slug])); ?>"><?php echo e($sub_menu->title); ?></a></li>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</ul>
												<?php else: ?>
												<a class="collapse-item" href="#"><?php echo e($cat_info->title); ?></a>
												<?php endif; ?>
											</div>
										</div>
									</li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</div>
						</ul>

						<!--/ End Single Widget -->

					</div>
				</div>
				<div class="col-lg-9 col-md-8 col-12">
					<div class="row">
						<div class="col-12">
							<!-- Shop Top -->
							<div class="asetit-top">
								<div class="asetit-shorter">
									<div class="single-shorter">
										<label>Show :</label>
										<select class="show" name="show" onchange="this.form.submit();">
											<option value="">Default</option>
											<option value="9" <?php if(!empty($_GET['show']) && $_GET['show']=='9' ): ?> selected <?php endif; ?>>09</option>
											<option value="15" <?php if(!empty($_GET['show']) && $_GET['show']=='15' ): ?> selected <?php endif; ?>>15</option>
											<option value="21" <?php if(!empty($_GET['show']) && $_GET['show']=='21' ): ?> selected <?php endif; ?>>21</option>
											<option value="30" <?php if(!empty($_GET['show']) && $_GET['show']=='30' ): ?> selected <?php endif; ?>>30</option>
										</select>
									</div>
									<div class="single-shorter">
										<label>Sort By :</label>
										<select class='sortBy' name='sortBy' onchange="this.form.submit();">
											<option value="">Default</option>
											<option value="title" <?php if(!empty($_GET['sortBy']) && $_GET['sortBy']=='title' ): ?> selected <?php endif; ?>>Name</option>
											<option value="stock" <?php if(!empty($_GET['sortBy']) && $_GET['sortBy']=='stock' ): ?> selected <?php endif; ?>>Stock</option>
											<option value="category" <?php if(!empty($_GET['sortBy']) && $_GET['sortBy']=='category' ): ?> selected <?php endif; ?>>Category</option>
										</select>
									</div>
								</div>
								<ul class="view-mode">
									<li><a href="<?php echo e(route('aset-grids')); ?>"><i class="fa fa-th-large"></i></a></li>
									<li class="active"><a href="javascript:void(0)"><i class="fa fa-th-list"></i></a></li>
								</ul>
							</div>
							<!--/ End Shop Top -->
						</div>
					</div>
					<div class="row">
						<?php if( count($asets)): ?>
						<?php $__currentLoopData = $asets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aset): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php
						$mainStatus = DB::table('maintenances')->where('aset_id', $aset->id)->value('mainStatus');
						?>
						<?php if(!$mainStatus || $mainStatus != 'Diperbaiki' && $mainStatus != 'Sedang Diproses' && $mainStatus != 'Maintenance' && $mainStatus != 'Repair'): ?>
						
						<!-- Start Single List -->
						<div class="col-12">
							<div class="row">
								<div class="col-lg-4 col-md-6 col-sm-6">
									<div class="single-aset">
										<div class="aset-img">
											<a href="<?php echo e(route('aset-detail',$aset->slug)); ?>" class="mt-2 mb-5">
												<?php
												$photo=explode(',',$aset->photo);
												?>
												<img class="default-img" src="<?php echo e($photo[0]); ?>" alt="<?php echo e($photo[0]); ?>">
											</a>
											<div class="button-head">
												<!-- <div class="aset-action">
															<a title="Wishlist" href="<?php echo e(route('add-to-wishlist',$aset->slug)); ?>" class="wishlist" data-id="<?php echo e($aset->id); ?>" style="margin-right: 10px;"><i class=" ti-heart "></i><span>Tambah ke Wishlist</span></a>
														</div> -->
												<div class="aset-action-2">
													<a title="Tambah ke Keranjang" href="<?php echo e(route('add-to-cart',$aset->slug)); ?>">Tambah ke Keranjang</a>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-lg-8 col-md-6 col-12">
									<div class="list-content">
										<div class="aset-content">
											<h3 class="title"><a href="<?php echo e(route('aset-detail',$aset->slug)); ?>"><?php echo e($aset->title); ?></a></h3>
										</div>
										<p class="des pt-2"><?php echo html_entity_decode($aset->summary); ?></p>
										<h6 class="stock">Stok: <?php echo e($aset->stock); ?></a></h6>
									</div>
								</div>
							</div>
						</div>
						<!-- End Single List -->
						<?php else: ?>
						<h4 class="text-warning" style="margin:100px auto;">Aset Sedang Dimaintenance.</h4>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php else: ?>
						<h4 class="text-warning" style="margin:100px auto;">Tidak Ada Aset.</h4>
						<?php endif; ?>
					</div>
					<div class="row">
						<div class="col-md-12 justify-content-center d-flex">
							<ul class="pagination justify-content-end">
								<li class="page-item <?php echo e(( $asets->previousPageUrl()) ? '' : 'disabled'); ?>">
									<a class="page-link" href="<?php echo e($asets ? $asets->previousPageUrl() : '#'); ?>" rel="prev">Previous</a>
								</li>

								<?php if($asets): ?>
								<?php for($i = 1; $i <= $asets->lastPage(); $i++): ?>
									<li class="page-item <?php echo e(($i == $asets->currentPage()) ? 'active' : ''); ?>">
										<a class="page-link" href="<?php echo e($asets->url($i)); ?>"><?php echo e($i); ?></a>
									</li>
									<?php endfor; ?>
									<?php endif; ?>

									<li class="page-item <?php echo e((  $asets->nextPageUrl()) ? '' : 'disabled'); ?>">
										<a class="page-link" href="<?php echo e($asets ? $asets->nextPageUrl() : '#'); ?>" rel="next">Next</a>
									</li>
							</ul>
						</div>
					</div>

				</div>
			</div>
		</div>
	</section>
	<!--/ End aset Style 1  -->
</form>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<style>
	.pagination {
		display: inline-flex;
	}

	.filter_button {
		/* height:20px; */
		text-align: center;
		background: #F7941D;
		padding: 8px 16px;
		margin-top: 10px;
		color: white;
	}

	.collapse-item {
		padding: .5rem 1rem;
		margin: 0 .5rem;
		display: block;
		color: #3a3b45;
		text-decoration: none;
		border-radius: .35rem;
		white-space: nowrap;
	}

	.collapse-item:hover {
		background-color: #eaecf4
	}

	collapse-item:active {
		background-color: #dddfeb;
		color: #4e73df;
		font-weight: 700;
	}

	.arrow-icon {
		float: right;
	}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
	$(document).ready(function() {
		$('.nav-link').click(function() {
			var $icon = $(this).find('.arrow-icon i');
			if ($(this).hasClass('collapsed')) {
				$icon.removeClass('fas fa-chevron-right').addClass('fas fa-chevron-down');
			} else {
				$icon.removeClass('fas fa-chevron-down').addClass('fas fa-chevron-right');
			}
		});
	});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aset-it\resources\views/frontend/pages/aset-lists.blade.php ENDPATH**/ ?>